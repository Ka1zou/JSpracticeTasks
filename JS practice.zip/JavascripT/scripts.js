
let name = "Arsen Serikov"
document.getElementById("name").value = name;





var group;
group = "CS - 2119";
document.getElementById("group").value = group;



var today = new Date();
var year = today.getFullYear();
document.getElementById("year").value = year;




var today = new Date();
var toDay = today.getDay();
switch (toDay) {
    case 1:
        toDay = "Monday";
        break;
    case 2:
        toDay = "Tuesday";
        break;
    case 3:
        toDay = "Wednesday";
        break;
    case 4:
        toDay = "Thursday";
        break;
    case 5:
        toDay = "Friday";
        break;
    case 6:
        toDay = "Saturday";
        break;
    case 7:
        toDay = "Sunday";
        break;
}
document.getElementById("Today").value =toDay;




var today = new Date();
var Day = today.getDate();
document.getElementById("day").value = Day;


var today = new Date();
var month = today.getMonth()+1 ;
document.getElementById("month").value = month;
switch (month) {
    case 1:
        month = "January";
        break;
    case 2:
        month = "February";
        break;
    case 3:
        month = "March";
        break;
    case 4:
        month = "April";
        break;
    case 5:
        month = "May";
        break;
    case 6:
        month = "June";
        break;
    case 7:
        month = "July";
        break;
    case 8:
        month = "August";
        break;
    case 9:
        month = "September";
        break;
    case 10:
        month = "October";
        break;
    case 11:
        month = "November";
        break;
    case 12:
        month = "December"
        break;
}
document.getElementById("month").value = month;




var today = new Date();
var time = today.getHours()+":"+ today.getMinutes() +":"+ today.getSeconds();
document.getElementById("time").value = time;






const oneDaay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
const firsttDate = new Date(2021, 9 , 1);
const seconndDate = new Date(2024, 7, 25);

const diffDays = Math.round(Math.abs((firsttDate - seconndDate) / oneDaay));
document.getElementById("graduation").value = diffDays;





function mul() {
    var a, b, Mul;
    a = parseInt(document.getElementById("num1").value);
    b = parseInt(document.getElementById("num2").value);
    Mul = a * b;

    document.getElementById("mul").innerHTML = "Multiplication of " + a + "*" + b + "= " + Mul;
}
function div(){
    var a,b,Div;
    a = parseInt(document.getElementById ("num1").value);
    b = parseInt(document.getElementById ("num2").value);
    Div = a/b;
    document.getElementById ("div").innerHTML ="Division of "+a+"/"+b+"= " +Div;
}